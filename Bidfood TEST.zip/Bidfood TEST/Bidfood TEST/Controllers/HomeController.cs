﻿using Bidfood_TEST.Models;
using Bidfood_TEST.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;


namespace Bidfood_TEST.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment WebHostEnvironment;

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            WebHostEnvironment = webHostEnvironment;
        }



        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Index(string firstName, string lastName)
        {
            ViewBag.Name = string.Format("Name: {0} {1}", firstName, lastName);
            ViewBag.FirstName = string.Format("FirstName: {0}", firstName);
            ViewBag.LastName = string.Format("LastName: {0}", lastName);

            
           
            return View();
        }

        public IActionResult JsonGen()
        {
            return View();
        }

        [HttpPost]
        public IActionResult JsonGen(Names names)
        {
            JObject obj = (JObject)JToken.FromObject(names);
            CreateFile(obj);
            return View();
        }

        
        
        private void CreateFile(JObject obj)
        {
            string upload = Path.Combine(WebHostEnvironment.WebRootPath, "Json");
            var fileName = Guid.NewGuid().ToString() + ".json";
            string filePath = Path.Combine(upload, fileName);
            System.IO.File.WriteAllText(filePath, obj.ToString());
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
