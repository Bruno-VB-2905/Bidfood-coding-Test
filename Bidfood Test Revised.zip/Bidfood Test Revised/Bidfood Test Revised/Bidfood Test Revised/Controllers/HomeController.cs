﻿using Bidfood_Test_Revised.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Xceed.Wpf.Toolkit;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Bidfood_Test_Revised.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment WebHostEnvironment;
        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            WebHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Names names, string firstName, string lastName)
        {
            ViewBag.FirstName = string.Format("First Name: {0}", firstName);
            ViewBag.LastName = string.Format("Last Name: {0}", lastName);
            JObject obj = (JObject)JToken.FromObject(names);
            CreateFile(obj);
            return View();
        }
        
        private void CreateFile(JObject obj)
        {
            string upload = Path.Combine(WebHostEnvironment.WebRootPath, "Json");
            //int a, b, c;
            //a = 0;
            //b = a++;
            //c = b;
            //var fileName = c.ToString() + ".json";
            var fileName = Guid.NewGuid().ToString() + ".json";
            string filePath = Path.Combine(upload, fileName);
            System.IO.File.WriteAllText(filePath, obj.ToString());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
