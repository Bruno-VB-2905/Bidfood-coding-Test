﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bidfood_Test_Revised.Models
{
    public class Names
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
